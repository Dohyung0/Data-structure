#pragma once
int testPair(char* exp);