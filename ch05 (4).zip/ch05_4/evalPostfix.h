#pragma once
element evalPostfix(char* exp);